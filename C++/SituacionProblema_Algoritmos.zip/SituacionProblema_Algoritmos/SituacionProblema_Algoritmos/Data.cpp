#include "Data.h"

Data::Data()
{
	id = 0;
	inf = ""; 
	ip ;
}

Data::Data(int x, string date, double y)
{
	id = x;
	inf = date;
	ip = y;
}

int Data::get_val()
{
	return id;
}

string Data::get_date()
{
	return inf;
}

double Data::get_ip()
{
	return ip;
}
