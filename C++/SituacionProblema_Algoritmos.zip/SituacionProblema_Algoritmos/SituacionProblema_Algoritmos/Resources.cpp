#include "Resources.h"
#include <iostream>
using namespace std;

void Resources::quickSort(std::vector<Data>& vec, int low, int high)
{
	if (low<high)
	{
		int part = partition(vec, low, high);
		quickSort(vec, low, part - 1);
		quickSort(vec, part + 1, high);
	}
}

int Resources::partition(std::vector<Data>& vec, int low, int high)
{
	int pivot = vec[high].get_ip();
	int i = (low - 1);

	for (int j=low; j<= high-1;j++)
	{
		if(vec[j].get_ip() <= pivot)
		{
			i++;
			swap(vec[i], vec[j]);

		}
	}
	swap(vec[i + 1], vec[high]);

	return (i+1);
}

int Resources::get_index()
{
	string ip_value ;

	cout << "Ingrese IP" << endl;
	cin >> ip_value;


	return Resources::def_ip(ip_value);

	
}

void Resources::display(std::vector<Data>& vec)
{
	cout << "||  IP DE INICIO  ||" << endl;
	int lowIndex = Resources::get_index();

	cout << "||  IP FINAL  ||" << endl ;
	int highIndex = Resources::get_index();
	cout << endl;
	int cont = 0;
	int imp = 0;

	while (vec[cont].get_ip() <= highIndex)
	{
		if (vec[cont].get_ip() >= lowIndex)
		{
			cout << vec[cont].get_date() << endl;
			imp++;
		}
		cont++;
	}
	if (imp==0)
	{
		cout << endl << "No se encontraron datos dentro del rango propocionado" << endl;
	}
}

double Resources::def_ip(string ip_val)
{
	double val1 = (stoi(ip_val.substr(0, ip_val.find_first_of("."))) + 100) * 1000000;
	ip_val.erase(0, ip_val.find_first_of(".") + 1);

	double val2 = (stoi(ip_val.substr(0, ip_val.find_first_of("."))) + 100) * 1000;
	ip_val.erase(0, ip_val.find_first_of(".") + 1);

	double val3 = (stoi(ip_val.substr(0, ip_val.find_first_of("."))) + 100);
	ip_val.erase(0, ip_val.find_first_of(".") + 1);

	double val4 = (stoi(ip_val.substr(0, ip_val.find_first_of(":"))) + 100) * 0.001;
	ip_val.erase(0, ip_val.find_first_of(":") + 1);

	double ip = val1 + val2 + val3 + val4  - 100100100.1000;

	return ip;
}

int Resources::def_date(string month)
{
	int tmp = 0;

	if (month == "Jun")
	{
		tmp += 600;
	}
	else if (month == "Jul")
	{
		tmp += 700;
	}
	else if (month == "Aug")
	{
		tmp += 800;
	}
	else if (month == "Sep")
	{
		tmp += 900;
	}
	else if (month == "Oct")
	{
		tmp += 1000;
	}
	return tmp;
}
