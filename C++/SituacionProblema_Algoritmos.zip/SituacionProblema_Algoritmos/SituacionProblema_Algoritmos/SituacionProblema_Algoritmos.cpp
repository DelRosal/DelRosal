// SituacionProblema_Algoritmos.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <iomanip>
#include <fstream>
#include<string.h>
#include "Data.h"
#include "Resources.h"
using namespace std;


int main()
{
	ifstream File("bitacora.txt");

	vector <Data> logs;
	string row;
	string month;

	double ip;
	string ip_val;
	int i = 0;

	while (getline(File, row))
	{
		month = row.substr(0, 3);
		ip_val = row.substr(15,18);
		ip = Resources::def_ip(ip_val);		
		int tmp = Resources::def_date(month) + stoi(row.substr(4, 2));
		logs.push_back(Data(tmp,row,ip));
		i++;

	}

	Resources::quickSort(logs, 0, i - 1);
	Resources::display(logs);


}

