#pragma once
#include <string>
#include <vector>
#include "Data.h"

using namespace std;

class Resources
{
public:
	static void quickSort(std::vector<Data>&, int, int);
	static int partition(std::vector<Data>&, int, int);

	static int get_index();

	static void display(std::vector<Data>&);

	static double def_ip(string);
	static int def_date(string);
};

