#pragma once
#include<string>

using namespace std;

class Data
{
private:
	int id;
	string inf;
	double ip;

public:
	Data();
	Data(int, string, double);

	int get_val();
	string get_date();
	double get_ip();

};

